BACKROOMS FULL OF DOORS

HI, welcome to the backrooms. You have entered the backrooms and need to 
find your way out.

You will need to choose carefully which door to enter, and hopefully they 
lead you to the right path of finding the exit.

If you find yourself at a deadend, input cd .. to get yourself back to the 
previous directory.

GOOD LUCK
